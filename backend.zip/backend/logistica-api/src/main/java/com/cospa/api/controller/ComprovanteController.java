package com.cospa.api.controller;

import com.cospa.api.model.Comprovante;
import com.cospa.api.repository.ComprovanteRepository;
import com.cospa.api.repository.ViagemRepository;
import net.coobird.thumbnailator.Thumbnails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/viagens")
@CrossOrigin(origins = "*")
public class ComprovanteController {

    @Autowired
    private ViagemRepository viagemRepository;

    @Autowired
    private ComprovanteRepository comprovanteRepository;

    @Value("${app.upload.dir:/app/uploads}")
    private String uploadDirConfig;

    private Path getUploadPath() {
        Path path = Paths.get(uploadDirConfig).toAbsolutePath().normalize();
        if (!Files.exists(path)) {
            try {
                Files.createDirectories(path);
            } catch (IOException e) {
                path = Paths.get(System.getProperty("user.dir"), "uploads").toAbsolutePath().normalize();
                try { Files.createDirectories(path); } catch (IOException ignored) {}
            }
        }
        return path;
    }

    @GetMapping("/{viagemId}/comprovantes")
    public ResponseEntity<List<Comprovante>> listarComprovantes(@PathVariable Long viagemId) {
        return ResponseEntity.ok(comprovanteRepository.findByViagemId(viagemId));
    }

    @PostMapping("/{viagemId}/comprovantes")
    public ResponseEntity<?> uploadComprovante(
            @PathVariable Long viagemId,
            @RequestParam("file") MultipartFile file,
            @RequestParam("nome") String nome) {

        return viagemRepository.findById(viagemId).map(viagem -> {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("Arquivo vazio.");
            }

            try {
                String contentType = file.getContentType();
                boolean isImagem = contentType != null && contentType.startsWith("image/");

                String extensao = "";
                String nomeOriginal = file.getOriginalFilename();
                if (nomeOriginal != null && nomeOriginal.contains(".")) {
                    extensao = nomeOriginal.substring(nomeOriginal.lastIndexOf("."));
                }

                // Força extensão .jpg se for imagem tratada para padronizar compressão
                if (isImagem) {
                    extensao = ".jpg";
                }

                String nomeArquivo = "viagem_" + viagemId + "_" + UUID.randomUUID().toString().substring(0, 8) + extensao;
                Path uploadFolder = getUploadPath();
                File destinoArquivo = uploadFolder.resolve(nomeArquivo).normalize().toFile();

                if (isImagem) {
                    // Redimensiona mantendo proporção (máx 1920x1080) e comprime a 75% de qualidade
                    Thumbnails.of(file.getInputStream())
                            .size(1920, 1080)
                            .outputFormat("jpg")
                            .outputQuality(0.75f)
                            .toFile(destinoArquivo);
                } else {
                    // Se for PDF ou outro tipo de documento, salva diretamente
                    Files.copy(file.getInputStream(), destinoArquivo.toPath(), StandardCopyOption.REPLACE_EXISTING);
                }

                String urlRelativa = "/uploads/" + nomeArquivo;
                Comprovante comprovante = new Comprovante(nome, urlRelativa, viagem);
                comprovanteRepository.save(comprovante);

                return ResponseEntity.ok(comprovante);
            } catch (IOException e) {
                return ResponseEntity.internalServerError().body("Erro ao salvar e otimizar arquivo.");
            }
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{viagemId}/comprovantes/{comprovanteId}")
    @Transactional
    public ResponseEntity<Void> deletarComprovante(
            @PathVariable Long viagemId,
            @PathVariable Long comprovanteId) {

        return comprovanteRepository.findById(comprovanteId).map(comprovante -> {
            try {
                if (comprovante.getUrlArquivo() != null) {
                    String nomeArquivo = comprovante.getUrlArquivo().substring(comprovante.getUrlArquivo().lastIndexOf('/') + 1);
                    Path arquivoFisico = getUploadPath().resolve(nomeArquivo);
                    Files.deleteIfExists(arquivoFisico);
                }
            } catch (Exception ignored) {}

            comprovanteRepository.delete(comprovante);
            return ResponseEntity.noContent().<Void>build();
        }).orElse(ResponseEntity.notFound().build());
    }
}