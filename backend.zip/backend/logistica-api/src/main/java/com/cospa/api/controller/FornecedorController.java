package com.cospa.api.controller;

import com.cospa.api.model.Fornecedor;
import com.cospa.api.repository.FornecedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fornecedores")
@CrossOrigin(origins = "*")
public class FornecedorController {

    @Autowired
    private FornecedorRepository fornecedorRepository;

    @GetMapping
    public ResponseEntity<List<Fornecedor>> listarTodos() {
        return ResponseEntity.ok(fornecedorRepository.findAll());
    }

    @PostMapping
    public ResponseEntity<Fornecedor> criar(@RequestBody Fornecedor fornecedor) {
        if (fornecedor.getFormaPagamento() != null) {
            fornecedor.setFormaPagamento(fornecedor.getFormaPagamento().toUpperCase().trim());
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(fornecedorRepository.save(fornecedor));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Fornecedor> atualizar(@PathVariable Long id, @RequestBody Fornecedor dados) {
        return fornecedorRepository.findById(id).map(f -> {
            f.setNome(dados.getNome());
            f.setCnpjCpf(dados.getCnpjCpf());
            f.setContato(dados.getContato());
            f.setTelefone(dados.getTelefone());
            f.setEmail(dados.getEmail());
            f.setChavePix(dados.getChavePix());

            if (dados.getFormaPagamento() != null) {
                f.setFormaPagamento(dados.getFormaPagamento().toUpperCase().trim());
            } else {
                f.setFormaPagamento(null);
            }

            f.setSituacao(dados.getSituacao() != null ? dados.getSituacao() : "ATIVO");
            f.setObs(dados.getObs());
            f.setObservacoes(dados.getObservacoes());
            f.setAtivo(dados.getAtivo() != null ? dados.getAtivo() : true);
            return ResponseEntity.ok(fornecedorRepository.save(f));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (!fornecedorRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        fornecedorRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}