package com.cospa.api.service;

import com.cospa.api.model.LancamentoFinanceiro;
import com.cospa.api.model.TituloFinanceiro;
import com.cospa.api.model.Viagem;
import com.cospa.api.repository.LancamentoFinanceiroRepository;
import com.cospa.api.repository.TituloFinanceiroRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FinanceiroService {

    private final TituloFinanceiroRepository tituloRepo;
    private final LancamentoFinanceiroRepository lancamentoRepo;
    private final ArquivoService arquivoService;

    @Transactional(readOnly = true)
    public List<TituloFinanceiro> listarPorTipo(String tipo) {
        return tituloRepo.findByTipoOrderByIdDesc(tipo);
    }

    @Transactional(readOnly = true)
    public List<LancamentoFinanceiro> listarTodosLancamentos() {
        return lancamentoRepo.findAllByOrderByIdDesc();
    }

    @Transactional
    public void gerarTitulosDaViagem(Viagem viagem) {
        if (viagem == null) return;

        BigDecimal freteReceber = viagem.getValorAReceber() != null ? viagem.getValorAReceber() : BigDecimal.ZERO;
        BigDecimal adicReceber = viagem.getValorAdicionalReceber() != null ? viagem.getValorAdicionalReceber() : BigDecimal.ZERO;
        BigDecimal totalReceber = freteReceber.add(adicReceber);

        BigDecimal fretePagar = viagem.getValorAPagar() != null ? viagem.getValorAPagar() : BigDecimal.ZERO;
        BigDecimal adicPagar = viagem.getValorAdicionalPagar() != null ? viagem.getValorAdicionalPagar() : BigDecimal.ZERO;
        BigDecimal totalPagar = fretePagar.add(adicPagar);

        // 1. Título a Receber (Cliente)
        TituloFinanceiro tituloReceber = tituloRepo.findByViagemIdAndTipo(viagem.getId(), "A RECEBER")
                .orElseGet(() -> TituloFinanceiro.builder()
                        .idTitulo("REC-" + viagem.getId())
                        .viagemId(viagem.getId())
                        .tipo("A RECEBER")
                        .build());

        tituloReceber.setEntidadeNome(viagem.getCliente() != null ? viagem.getCliente() : "NÃO INFORMADO");
        tituloReceber.setOperacao(viagem.getTipoOperacao() != null ? viagem.getTipoOperacao().name() : "");
        tituloReceber.setNumeroRota(viagem.getNumeroOperacional() != null ? viagem.getNumeroOperacional() : "");
        tituloReceber.setOrigem(viagem.getOrigem());
        tituloReceber.setDestino(viagem.getDestino());
        tituloReceber.setPerfilVeiculo(viagem.getPerfilVeiculo());
        tituloReceber.setPlaca(viagem.getPlaca());
        tituloReceber.setValorFrete(freteReceber);
        tituloReceber.setValorAdicional(adicReceber);
        tituloReceber.setTotalPrevisto(totalReceber);
        if (tituloReceber.getId() == null) {
            tituloReceber.setTotalRealizado(BigDecimal.ZERO);
            tituloReceber.setSaldoEmAberto(totalReceber);
            tituloReceber.setStatus("PENDENTE");
        }
        tituloRepo.save(tituloReceber);

        // 2. Título a Pagar (Motorista / Fornecedor)
        String entidadePagar = (viagem.getNomeMotorista() != null && !viagem.getNomeMotorista().isBlank())
                ? viagem.getNomeMotorista()
                : (viagem.getFornecedorAgencia() != null ? viagem.getFornecedorAgencia() : "A CONTRATAR");

        TituloFinanceiro tituloPagar = tituloRepo.findByViagemIdAndTipo(viagem.getId(), "A PAGAR")
                .orElseGet(() -> TituloFinanceiro.builder()
                        .idTitulo("PAG-" + viagem.getId())
                        .viagemId(viagem.getId())
                        .tipo("A PAGAR")
                        .build());

        tituloPagar.setEntidadeNome(entidadePagar);
        tituloPagar.setOperacao(viagem.getTipoOperacao() != null ? viagem.getTipoOperacao().name() : "");
        tituloPagar.setNumeroRota(viagem.getNumeroOperacional() != null ? viagem.getNumeroOperacional() : "");
        tituloPagar.setOrigem(viagem.getOrigem());
        tituloPagar.setDestino(viagem.getDestino());
        tituloPagar.setPerfilVeiculo(viagem.getPerfilVeiculo());
        tituloPagar.setPlaca(viagem.getPlaca());
        tituloPagar.setValorFrete(fretePagar);
        tituloPagar.setValorAdicional(adicPagar);
        tituloPagar.setTotalPrevisto(totalPagar);
        if (tituloPagar.getId() == null) {
            tituloPagar.setTotalRealizado(BigDecimal.ZERO);
            tituloPagar.setSaldoEmAberto(totalPagar);
            tituloPagar.setStatus("PENDENTE");
        }
        tituloRepo.save(tituloPagar);
    }

    @Transactional
    public LancamentoFinanceiro realizarBaixa(Long lancamentoId, BigDecimal valorRealizado, String dataEfetiva, MultipartFile arquivo, String obs) {
        LancamentoFinanceiro lancamento = lancamentoRepo.findById(lancamentoId)
                .orElseThrow(() -> new RuntimeException("Lançamento não encontrado: " + lancamentoId));

        lancamento.setValorRealizado(valorRealizado != null ? valorRealizado : lancamento.getValorPrevisto());
        lancamento.setDataEfetiva(dataEfetiva);
        lancamento.setSaldoEmAberto(lancamento.getValorPrevisto().subtract(lancamento.getValorRealizado()).max(BigDecimal.ZERO));
        lancamento.setStatus(lancamento.getSaldoEmAberto().compareTo(BigDecimal.ZERO) == 0 ? "QUITADO" : "PARCIAL");

        if (obs != null && !obs.isBlank()) {
            lancamento.setObservacao(obs);
        }

        if (arquivo != null && !arquivo.isEmpty()) {
            String url = arquivoService.salvarComprovante(arquivo);
            lancamento.setComprovanteUrl(url);
        }

        LancamentoFinanceiro salvo = lancamentoRepo.save(lancamento);

        // Atualizar saldo do título consolidado
        TituloFinanceiro titulo = lancamento.getTitulo();
        if (titulo != null) {
            List<LancamentoFinanceiro> parcelas = lancamentoRepo.findByTituloIdOrderByIdAsc(titulo.getId());
            BigDecimal somaRealizada = parcelas.stream()
                    .map(LancamentoFinanceiro::getValorRealizado)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            titulo.setTotalRealizado(somaRealizada);
            titulo.setSaldoEmAberto(titulo.getTotalPrevisto().subtract(somaRealizada).max(BigDecimal.ZERO));

            if (titulo.getSaldoEmAberto().compareTo(BigDecimal.ZERO) == 0) {
                titulo.setStatus("QUITADO");
            } else if (somaRealizada.compareTo(BigDecimal.ZERO) > 0) {
                titulo.setStatus("PARCIAL");
            }
            tituloRepo.save(titulo);
        }

        return salvo;
    }
}