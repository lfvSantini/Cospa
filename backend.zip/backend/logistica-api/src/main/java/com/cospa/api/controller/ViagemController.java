package com.cospa.api.controller;

import com.cospa.api.dto.ViagemRequestDTO;
import com.cospa.api.dto.ViagemResponseDTO;
import com.cospa.api.model.Viagem;
import com.cospa.api.service.ViagemService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/viagens")
@CrossOrigin(
        origins = "*",
        allowedHeaders = "*",
        methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.PATCH, RequestMethod.DELETE, RequestMethod.OPTIONS}
)
public class ViagemController {

    @Autowired
    private ViagemService viagemService;

    @GetMapping
    public ResponseEntity<List<ViagemResponseDTO>> listarTodas() {
        List<ViagemResponseDTO> lista = viagemService.listarTodas().stream()
                .map(ViagemResponseDTO::new)
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ViagemResponseDTO> buscarPorId(@PathVariable Long id) {
        return viagemService.buscarPorId(id)
                .map(v -> ResponseEntity.ok(new ViagemResponseDTO(v)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ViagemResponseDTO> criar(@RequestBody @Valid ViagemRequestDTO dto) {
        Viagem salva = viagemService.salvar(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(new ViagemResponseDTO(salva));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ViagemResponseDTO> atualizar(@PathVariable Long id, @RequestBody @Valid ViagemRequestDTO dto) {
        return viagemService.atualizar(id, dto)
                .map(v -> ResponseEntity.ok(new ViagemResponseDTO(v)))
                .orElse(ResponseEntity.notFound().build());
    }

    @PatchMapping("/{id}/cancelar")
    public ResponseEntity<ViagemResponseDTO> cancelar(@PathVariable Long id, @RequestBody(required = false) Map<String, String> payload) {
        String motivo = (payload != null) ? payload.get("motivo") : null;
        return viagemService.cancelar(id, motivo)
                .map(v -> ResponseEntity.ok(new ViagemResponseDTO(v)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        boolean deletado = viagemService.deletar(id);
        if (!deletado) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
}